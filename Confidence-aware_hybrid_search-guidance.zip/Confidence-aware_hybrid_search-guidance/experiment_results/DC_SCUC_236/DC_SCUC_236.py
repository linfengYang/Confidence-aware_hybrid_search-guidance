from solver.DC_SCUC_Gurobi_model import DC_SCUC_Gurobi_model
import numpy as np
import torch
import time
from utlis.read_dataset import read_dataset_from_txt
import joblib
from utlis.model_predict import predict_u_by_model
from run.model.RGCTCN import *

def myrun(eta_soft, use_guidance, use_mip_start, file_name):
    # 参数获取
    G = int(108)
    N = int(236)
    T = int(24)
    L = int(373)
    # 获取机组参数
    from utlis.get_108_236_data import get_data
    data = get_data(r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\utlis\SCUC236.txt")

    # 记录数据
    optimize_time = []
    original_obj = []
    penalty_obj = []
    total_obj = []
    u_values = []
    continuous_var_num = []
    binary_var_num = []
    orig_rows = []
    orig_cols = []
    orig_nonzeros = []
    pres_rows = []
    pres_cols = []
    pres_nonzeros = []
    presolve_time = []
    model_infer_time = []
    explored_node = []

    # 设置求解停止间隙
    MIPGap = 0.0001
    # 是否线性化
    MILP_flag = 1

    # 加载模型
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    model_path = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\weights\model[236]_Epoch[361]_TrainingLoss[0.020450]_ValidationLoss[0.019893].pth"
    scaler_path = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\scaler\system_load_scaler_236.pkl"
    dataset_test_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_108_236\test"
    X, _ = read_dataset_from_txt(dataset_test_dir, G, N)

    my_model = RGCTCN_M(num_units=G, input_channels=N + 1)
    my_model.load_state_dict(torch.load(model_path, map_location=device))
    my_model.to(device)
    my_model.eval()

    # 加载归一化器
    scaler = joblib.load(scaler_path)

    for i in range(X.shape[0]):
        P_D = (X[i, 0, :]).copy()
        nodes_load_P = X[i, 1:, :]
        hourly_sum = nodes_load_P.sum(axis=0, keepdims=True)
        nodes_load_percentage_P = nodes_load_P / hourly_sum

        # 使用模型预测开关机决策概率
        model_infer_start = time.perf_counter()
        u_hat, u_conf, prob = predict_u_by_model(
            P_D_raw=P_D,
            nodes_load_percentage_P=nodes_load_percentage_P,
            model=my_model,
            scaler=scaler,
            device=device,
            threshold=0.5
        )
        model_infer_end = time.perf_counter()

        DC_SCUC = DC_SCUC_Gurobi_model(G, N, T, L, data["alpha"], data["beta"], data["gamma"],
                                       data["hot_su_cost"], data["cold_su_cost"],
                                       data["min_on"], data["min_off"], data["cold_su_t"], data["P_max"],
                                       data["P_min"], data["ramp_up"], data["ramp_down"], data["su_ramp"],
                                       data["sd_ramp"],
                                       data["unit_init_status"], data["T_init"], data["node_connections"],
                                       nodes_load_percentage_P, data["lines"], data["P_ij_max"],
                                       data["B_matrix"],
                                       P_D * 0.01, data["P_init"], data["unit_bus"], data["balance_node"], MIPGap, MILP_flag, u_hat=u_hat,
                                       u_conf=u_conf, eta_soft=eta_soft, use_guidance=use_guidance, use_mip_start=use_mip_start)
        u1, s1, d1, original_obj1, penalty_obj1, total_obj1, t1, continuous_var_num1, binary_var_num1, orig_rows1, orig_cols1, orig_nonzeros1, pres_rows1, pres_cols1, pres_nonzeros1, presolve_time1, node_count = DC_SCUC.myOptimize()
        u_values.append(u1)
        original_obj.append(original_obj1)
        penalty_obj.append(penalty_obj1)
        total_obj.append(total_obj1)
        optimize_time.append(t1)
        model_infer_time.append(model_infer_end - model_infer_start)
        continuous_var_num.append(continuous_var_num1)
        binary_var_num.append(binary_var_num1)
        orig_rows.append(orig_rows1)
        orig_cols.append(orig_cols1)
        orig_nonzeros.append(orig_nonzeros1)
        pres_rows.append(pres_rows1)
        pres_cols.append(pres_cols1)
        pres_nonzeros.append(pres_nonzeros1)
        presolve_time.append(presolve_time1)
        explored_node.append(node_count)

    from utlis.save_result import save_results

    # 保存结果, 根据需要修改名字
    name = file_name
    save_results(u_values, original_obj, penalty_obj, total_obj, optimize_time, model_infer_time, continuous_var_num, binary_var_num,
                 orig_rows, orig_cols,
                 orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, explored_node, name,
                 output_dir=r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236")


if __name__ == '__main__':
    info_set = [
        {
            "eta_soft": 1.0,
            "use_guidance": True,
            "use_mip_start": True,
            "file_name": "Acceleration_Optimization_info_eta_[1.0]_MILP_236"
        },
        {
            "eta_soft": 1.0,
            "use_guidance": True,
            "use_mip_start": False,
            "file_name": "NoMIPStart_Acceleration_Optimization_info_eta_[1.0]_MILP_236"
        },
        {
            "eta_soft": 10.0,
            "use_guidance": True,
            "use_mip_start": True,
            "file_name": "Acceleration_Optimization_info_eta_[10.0]_MILP_236"
        },
        {
            "eta_soft": 10.0,
            "use_guidance": True,
            "use_mip_start": False,
            "file_name": "NoMIPStart_Acceleration_Optimization_info_eta_[10.0]_MILP_236"
        },
        {
            "eta_soft": 25.0,
            "use_guidance": True,
            "use_mip_start": True,
            "file_name": "Acceleration_Optimization_info_eta_[25.0]_MILP_236"
        },
        {
            "eta_soft": 25.0,
            "use_guidance": True,
            "use_mip_start": False,
            "file_name": "NoMIPStart_Acceleration_Optimization_info_eta_[25.0]_MILP_236"
        },
        {
            "eta_soft": 50.0,
            "use_guidance": True,
            "use_mip_start": True,
            "file_name": "Acceleration_Optimization_info_eta_[50.0]_MILP_236"
        },
        {
            "eta_soft": 50.0,
            "use_guidance": True,
            "use_mip_start": False,
            "file_name": "NoMIPStart_Acceleration_Optimization_info_eta_[50.0]_MILP_236"
        },
        {
            "eta_soft": 1.0,
            "use_guidance": False,
            "use_mip_start": True,
            "file_name": "OnlyMIPStart_Acceleration_Optimization_info_MILP_236"
        },
        {
            "eta_soft": 1.0,
            "use_guidance": False,
            "use_mip_start": False,
            "file_name": "Origin_Optimization_info_MILP_236"
        }
    ]

    for info in info_set:

        myrun(
            eta_soft=info["eta_soft"],
            use_guidance=info["use_guidance"],
            use_mip_start=info["use_mip_start"],
            file_name=info["file_name"]
        )

        print(f"实验完成: {info['file_name']}\n")