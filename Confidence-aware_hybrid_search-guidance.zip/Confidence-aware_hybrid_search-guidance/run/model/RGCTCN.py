import torch
import torch.nn as nn
import torch.nn.functional as F


class ResTCNBlock(nn.Module):
    def __init__(self, channels, dilation, dropout=0.1):
        super().__init__()
        self.conv1 = nn.Conv1d(
            channels, channels,
            kernel_size=3,
            padding=dilation,
            dilation=dilation
        )
        self.norm1 = nn.BatchNorm1d(channels)

        self.conv2 = nn.Conv1d(
            channels, channels,
            kernel_size=3,
            padding=dilation,
            dilation=dilation
        )
        self.norm2 = nn.BatchNorm1d(channels)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.norm1(out)
        out = F.relu(out)
        out = self.dropout(out)

        out = self.conv2(out)
        out = self.norm2(out)

        out = F.relu(out + residual)
        return out

class _RGCTCNBase(nn.Module):
    def __init__(
        self,
        num_units,
        input_channels,
        max_input_channels,
        stem_dim,
        hidden_dim,
        dilations,
        dropout=0.1
    ):
        super().__init__()

        if input_channels > max_input_channels:
            raise ValueError(
                f"当前模型最多支持 input_channels <= {max_input_channels}，"
                f"但你传入的是 {input_channels}"
            )

        self.num_units = num_units
        self.input_channels = input_channels

        self.stem = nn.Sequential(
            nn.Conv1d(input_channels, stem_dim, kernel_size=3, padding=1),
            nn.GroupNorm(
                num_groups=choose_group_num(stem_dim),
                num_channels=stem_dim
            ),
            nn.ReLU(),

            nn.Conv1d(stem_dim, hidden_dim, kernel_size=5, padding=2),
            nn.GroupNorm(
                num_groups=choose_group_num(hidden_dim),
                num_channels=hidden_dim
            ),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.tcn = nn.Sequential(
            *[
                ResTCNBlock(
                    channels=hidden_dim,
                    dilation=d,
                    dropout=dropout
                )
                for d in dilations
            ]
        )

        self.fusion = nn.Sequential(
            nn.Conv1d(hidden_dim * 3, hidden_dim, kernel_size=1),
            nn.GroupNorm(
                num_groups=choose_group_num(hidden_dim),
                num_channels=hidden_dim
            ),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.out = nn.Conv1d(hidden_dim, num_units, kernel_size=1)

    def forward(self, x):
        """
        x: [B, input_channels, T]
        return logits: [B, num_units, T]
        """
        h = self.stem(x)        # [B, hidden_dim, T]
        h = self.tcn(h)         # [B, hidden_dim, T]

        T = h.size(2)

        h_avg = torch.mean(h, dim=2, keepdim=True)       # [B, hidden_dim, 1]
        h_max = torch.max(h, dim=2, keepdim=True)[0]     # [B, hidden_dim, 1]

        h_cat = torch.cat([h, h_avg, h_max], dim=1)      # [B, hidden_dim*3, T]

        h_fuse = self.fusion(h_cat)                      # [B, hidden_dim, T]

        logits = self.out(h_fuse)                        # [B, num_units, T]
        return logits

class RGCTCN_N(_RGCTCNBase):
    """
    Nano 版本：
    适合 input_channels <= 64
    """
    def __init__(self, num_units, input_channels, dropout=0.1):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=64,
            stem_dim=32,
            hidden_dim=32,
            dilations=[1, 2],
            dropout=dropout
        )

class RGCTCN_S(_RGCTCNBase):
    """
    Small 版本：
    适合 input_channels <= 128
    """
    def __init__(self, num_units, input_channels, dropout=0.1):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=128,
            stem_dim=32,
            hidden_dim=64,
            dilations=[1, 2, 4],
            dropout=dropout
        )


class RGCTCN_M(_RGCTCNBase):
    """
    Medium 版本：
    适合 input_channels <= 256
    """
    def __init__(self, num_units, input_channels, dropout=0.1):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=256,
            stem_dim=48,
            hidden_dim=96,
            dilations=[1, 2, 4],
            dropout=dropout
        )


class RGCTCN_L(_RGCTCNBase):
    """
    Large 版本：
    适合 input_channels <= 384
    """
    def __init__(self, num_units, input_channels, dropout=0.1):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=384,
            stem_dim=64,
            hidden_dim=128,
            dilations=[1, 2, 4, 8],
            dropout=dropout
        )


class RGCTCN_U(_RGCTCNBase):
    """
    Ultra 版本：
    适合 input_channels <= 512
    """
    def __init__(self, num_units, input_channels, dropout=0.1):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=512,
            stem_dim=96,
            hidden_dim=192,
            dilations=[1, 2, 4, 8],
            dropout=dropout
        )

class TemporalSmoothL2Loss(nn.Module):
    def __init__(self, apply_sigmoid=True):
        super().__init__()
        self.apply_sigmoid = apply_sigmoid

    def forward(self, logits, target=None):
        if self.apply_sigmoid:
            prob = torch.sigmoid(logits)
        else:
            prob = logits

        diff = prob[:, :, 1:] - prob[:, :, :-1]

        loss = torch.mean(diff ** 2)

        return loss


class BCEW_TS_Loss(nn.Module):
    def __init__(self, lambda_smooth=0.01, pos_weight=None):
        super().__init__()

        self.bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        self.lambda_smooth = lambda_smooth

    def forward(self, logits, target):
        loss_bce = self.bce(logits, target.float())
        loss_smooth = self.smooth(logits, target.float())

        loss = loss_bce + self.lambda_smooth * loss_smooth

        return loss