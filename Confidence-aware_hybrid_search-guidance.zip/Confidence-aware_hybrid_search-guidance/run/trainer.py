import torch
import time

class trainer:
    def __init__(self, model, loss_fn, optimizer, scheduler, device, patience=15, epochs=100, clip=1.0, warmup=30):
        self.model = model
        self.loss_fn = loss_fn
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.device = device
        self.warmup = warmup
        self.patience = patience
        self.epochs = epochs
        self.clip = clip
        self.early_stop_counter = 0
        self.best_loss = float("inf")
        self.best_model = None

    def train(self, train_loader, val_loader):
        # 训练开始时间
        tick = time.perf_counter()
        # 初始化早停标志
        stop_training = False
        for epoch in range(self.epochs):
            # 初始化训练损失
            train_loss = 0.0
            if stop_training:
                break
            # 训练模式
            self.model.train()
            for inputs, Y_label in train_loader:
                # 将数据移动到GPU上
                inputs, Y_label = inputs.to(self.device), Y_label.to(self.device)
                # 梯度归零
                self.optimizer.zero_grad()
                # 前向传播
                outputs = self.model(inputs)
                # 计算损失
                loss = self.loss_fn(outputs, Y_label)
                # 反向传播
                loss.backward()
                # 梯度裁剪（防止梯度爆炸）
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip)
                # 优化
                self.optimizer.step()
                # 累加损失
                train_loss += loss.item() * inputs.size(0)

            # 学习率衰减
            self.scheduler.step()
            # 计算平均损失
            avg_train_loss = train_loss / len(train_loader.dataset)
            # 评估模型
            stop_training = self.validate(epoch, val_loader, avg_train_loss)
        # 训练结束时间
        tock = time.perf_counter()
        print("Training complete.")
        print(f"The training time is {(tock - tick):.2f} sec.")

        # 最终测试
        self.final_test(train_loader, "训练集")
        self.final_test(val_loader, "验证集")

    def validate(self, epoch, val_loader, avg_train_loss):
        # 验证阶段
        self.model.eval()
        # 初始化验证损失
        val_loss = 0.0
        with torch.no_grad():
            for inputs, Y_label in val_loader:
                # 将数据移动到GPU上
                inputs, Y_label = inputs.to(self.device), Y_label.to(self.device)
                outputs = self.model(inputs)
                loss = self.loss_fn(outputs, Y_label)
                val_loss += loss.item() * Y_label.size(0)
        avg_val_loss = val_loss / len(val_loader.dataset)
        print(f"Epoch {epoch}, Training Loss: {avg_train_loss:.6f}, Validation Loss: {avg_val_loss:.6f}")
        # 检验早停
        if epoch > self.warmup:
            self.check_early_stop(avg_val_loss,
                                  f"C:/Users/kentis/PycharmProjects/NN_Acceleration_Framework/weights/model_Epoch[{epoch}]_TrainingLoss[{avg_train_loss:.6f}]_ValidationLoss[{avg_val_loss:.6f}].pth")
        if self.early_stop_counter >= self.patience:
            print(f"Early stopping at epoch {epoch}")
            return True
        else:
            return False

    def check_early_stop(self, avg_val_loss, model_save_path):
        if avg_val_loss < self.best_loss:
            self.best_loss = avg_val_loss  # 更新最好损失
            self.early_stop_counter = 0
            self.best_model = model_save_path  # 记录最好模型权重
        else:
            self.early_stop_counter += 1

    def final_test(self, val_loader, name):
        if self.best_model is not None:
            torch.save(self.model.state_dict(), self.best_model)
            self.model.load_state_dict(torch.load(self.best_model))
            print("\n")
        self.model.eval()
        self.model.load_state_dict(torch.load(self.best_model))
        total_samples = 0
        incorrect_samples = 0
        error_distribution = {}  # 存储错误位置数量的分布
        sample_errors = []  # 存储每个错误样本的错误位置数量
        error_details = []  # 存储每个错误样本的详细信息
        with torch.no_grad():
            for batch_idx, (inputs, Y_label) in enumerate(val_loader):
                inputs, Y_label = inputs.to(self.device), Y_label.to(self.device)
                outputs = self.model(inputs)
                predictions = (torch.sigmoid(outputs) > 0.5).float()
                batch_size = inputs.size(0)
                total_samples += batch_size

                # 检查每个样本是否有任何位置预测错误
                mismatches = (predictions != Y_label)

                # 计算每个样本的错误位置数量
                errors_per_sample = mismatches.sum(dim=tuple(range(1, mismatches.dim())))

                # 检查每个样本是否有至少一个错误
                sample_has_error = (errors_per_sample > 0)
                incorrect_samples += sample_has_error.sum().item()

                # 遍历批次中的每个样本
                for i in range(batch_size):
                    num_errors = errors_per_sample[i].item()

                    if num_errors > 0:
                        # 记录错误位置数量
                        error_distribution[num_errors] = error_distribution.get(num_errors, 0) + 1
                        sample_errors.append(num_errors)

                        # 存储详细错误信息
                        error_details.append({
                            "batch_idx": batch_idx,
                            "sample_idx": i,
                            "num_errors": num_errors,
                            "input": inputs[i].cpu().numpy(),
                            "prediction": predictions[i].cpu().numpy(),
                            "label": Y_label[i].cpu().numpy(),
                            "errors": mismatches[i].cpu().numpy()
                        })
                # 计算平均错误位置数量
            avg_errors_per_sample = sum(sample_errors) / len(sample_errors) if sample_errors else 0

            # 计算错误率
            error_rate = sum(sample_errors) / (total_samples * predictions.size(1) * predictions.size(2))

            # 打印整体统计信息
            print(f"==============={name}准确率测试===============")
            print(f"样本总数: {total_samples}")
            print(f"平均每个错误样本的错误位置数量: {avg_errors_per_sample:.2f}")
            print(f"{name}总体预测正确率: {(1 - error_rate):.4f}")

            # 打印错误分布
            print("\n错误位置数量分布:")
            sorted_keys = sorted(error_distribution.keys())
            for num_errors in sorted_keys:
                count = error_distribution[num_errors]
                percentage = count / incorrect_samples * 100
                print(f" 错误位置数 {num_errors}: {count} 个样本 ({percentage:.1f}%)")