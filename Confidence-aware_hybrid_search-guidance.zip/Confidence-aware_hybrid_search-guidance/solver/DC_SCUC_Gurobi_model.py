from gurobipy import *
import numpy as np
from collections import defaultdict
import time
import torch

class DC_SCUC_Gurobi_model:
    def __init__(self, G, N, T, L, alpha, beta, gamma, hot_su_cost, cold_su_cost,
        min_on, min_off, cold_su_t, P_max, P_min, ramp_up, ramp_down, su_ramp, sd_ramp,
        unit_init_status, T_init, node_connections, nodes_load_percentage_P, lines, P_ij_max, B_matrix,
        P_D, P_init, unit_bus, balance_node, MIPGap, MILP_flag, u_hat=None, u_conf=None, eta_soft=0.1, use_guidance=False, use_mip_start=False):
        self.m = Model()
        self.m.Params.MIPGap = MIPGap
        # 创建变量
        # 机组状态变量
        u = tupledict()
        for i in range(G):
            for t in range(T):
                u[i, t] = self.m.addVar(vtype=GRB.BINARY, name='u' + '(' + str(i) + ',' + str(t) + ')')

        # 机组开机动作变量
        s = tupledict()
        for i in range(G):
            for t in range(T):
                s[i, t] = self.m.addVar(vtype=GRB.BINARY, name='s' + '(' + str(i) + ',' + str(t) + ')')

        # 机组关机动作变量
        d = tupledict()
        for i in range(G):
            for t in range(T):
                d[i, t] = self.m.addVar(vtype=GRB.BINARY, name='d' + '(' + str(i) + ',' + str(t) + ')')

        # 开机费用变量
        S = tupledict()
        for i in range(G):
            for t in range(T):
                S[i, t] = self.m.addVar(lb=0, vtype=GRB.CONTINUOUS, name='S' + '(' + str(i) + ',' + str(t) + ')')

        # 机组功率输出变量
        P = tupledict()
        for i in range(G):
            for t in range(T):
                P[i, t] = self.m.addVar(lb=0, ub=P_max[i], vtype=GRB.CONTINUOUS, name='P' + '(' + str(i) + ',' + str(t) + ')')

        # 节点相角变量
        theta = tupledict()
        for i in range(N):
            for t in range(T):
                theta[i, t] = self.m.addVar(vtype=GRB.CONTINUOUS, name='theta' + '(' + str(i) + ',' + str(t) + ')')

        # 线路功率流变量
        P_ij = tupledict()
        for l in range(L):
            for t in range(T):
                P_ij[l, t] = self.m.addVar(lb=- P_ij_max[l], ub=P_ij_max[l], vtype=GRB.CONTINUOUS, name='P_ij' + '(' + str(l) + ',' + str(t) + ')')


        # 创建目标函数
        # MILP = 1 代表目标函数线性化
        if MILP_flag == 0:
            original_cost = QuadExpr()
            original_cost += quicksum(u[i, t] * alpha[i] for i in range(G) for t in range(T))
            original_cost += quicksum(P[i, t] * beta[i] * 100 for i in range(G) for t in range(T))
            original_cost += quicksum(P[i, t] * P[i, t] * gamma[i] * 10000 for i in range(G) for t in range(T))
            original_cost += quicksum(S[i, t] for i in range(G) for t in range(T))
        else:
            original_cost = LinExpr()
            D = 4
            z_sup = tupledict()
            for i in range(G):
                for t in range(T):
                    z_sup[i, t] = self.m.addVar(lb=0, vtype=GRB.CONTINUOUS,
                                                name='z_sup' + '(' + str(i) + ',' + str(t) + ')')
            for l in range(D + 1):
                for i in range(G):
                    p_il = P_min[i] * 100 + l * (P_max[i] * 100 - P_min[i] * 100) / D
                    for t in range(T):
                        self.m.addConstr(z_sup[i, t] >= (2 * gamma[i] * p_il + beta[i]) * P[i, t] * 100 + (
                                    alpha[i] - gamma[i] * p_il * p_il) * u[i, t])
            original_cost += quicksum(z_sup[i, t] for i in range(G) for t in range(T))
            original_cost += quicksum(S[i, t] for i in range(G) for t in range(T))

        soft_penalty = LinExpr()

        total_cost = original_cost + soft_penalty

        self.m.setObjective(total_cost, GRB.MINIMIZE)

        # 添加约束

        # 开关机费用约束
        def f_init(i, t):
            temp_tau = t + 1 - min_off[i] - cold_su_t[i]
            if temp_tau <= 0:
                if max(0, - T_init[i]) < (abs(temp_tau - 1) + 1) :
                    return 1
            return 0

        for i in range(G):
            for t in range(T):
                self.m.addConstr(S[i, t] >= hot_su_cost[i] * s[i, t])
        for i in range(G):
            for t in range(T):
                tau_init = max(t + 1 - min_off[i] - cold_su_t[i], 1)
                self.m.addConstr(S[i, t] >= cold_su_cost[i] * ((s[i, t] - quicksum(d[i, tau] for tau in range(tau_init - 1, t))) - f_init(i, t)))

        # 功率平衡约束
        for k in range(N):
            for t in range(T):
                connected_nodes = node_connections[k]
                P_gen = quicksum(P[i, t] for i in range(G) if unit_bus[i] == k)
                sum1 = quicksum(B_matrix[k, j] * (theta[k, t] - theta[j, t]) for j in connected_nodes)
                self.m.addConstr(P_gen - nodes_load_percentage_P[k, t] * P_D[t] - sum1 == 0)

        # 线路功率流约束
        for k in range(L):
            for t in range(T):
                self.m.addConstr(P_ij[k, t] >= -P_ij_max[k])
                self.m.addConstr(P_ij[k, t] <= P_ij_max[k])
        z = 0
        for k in lines:
            for t in range(T):
                self.m.addConstr(P_ij[z, t] == B_matrix[k[0] - 1, k[1] - 1] * (theta[k[0] - 1, t] - theta[k[1] - 1, t]))
            z += 1

        # 固定参考节点
        for t in range(T):
            self.m.addConstr(theta[balance_node - 1, t] == 0)

        # 机组功率约束
        for i in range(G):
            for t in range(T):
                self.m.addConstr(P[i, t] >= u[i, t] * P_min[i])
                self.m.addConstr(P[i, t] <= u[i, t] * P_max[i])

        # 爬坡约束
        for i in range(G):
            self.m.addConstr(P[i, 0] - P_init[i] <= u[i, 0] * (ramp_up[i] + P_min[i]) - unit_init_status[i] * P_min[i] + s[i, 0] * (su_ramp[i] - ramp_up[i] - P_min[i]))
            self.m.addConstr(P_init[i] - P[i, 0] <= unit_init_status[i] * (ramp_down[i] + P_min[i]) - u[i, 0] * P_min[i] + d[i, 0] * (sd_ramp[i] - ramp_down[i] - P_min[i]))
            for t in range(1, T):
                self.m.addConstr(P[i, t] - P[i, t-1] <= u[i, t] * (ramp_up[i] + P_min[i]) - u[i, t-1] * P_min[i] + s[i, t] * (su_ramp[i] - ramp_up[i] - P_min[i]))
                self.m.addConstr(P[i, t-1] - P[i, t] <= u[i, t-1] * (ramp_down[i] + P_min[i]) - u[i, t] * P_min[i] + d[i, t] * (sd_ramp[i] - ramp_down[i] - P_min[i]))

        # 最小开关机时间约束
        for i in range(G):
            U_i = max(0, min(T, unit_init_status[i] * (min_on[i] - T_init[i])))
            L_i = max(0, min(T, (1 - unit_init_status[i]) * (min_off[i] + T_init[i])))
            for t in range(U_i, T):
                self.m.addConstr(quicksum(s[i, k] for k in range(max(0, t + 1 - min_on[i]), t + 1)) <= u[i, t])
            for t in range(L_i, T):
                self.m.addConstr(quicksum(d[i, k] for k in range(max(0, t + 1 - min_off[i]), t + 1)) <= 1 - u[i, t])
            for t in range(U_i + L_i):
                self.m.addConstr(u[i, t] == unit_init_status[i])

        # 机组状态约束
        for i in range(G):
            t = 0
            self.m.addConstr((s[i, t] - d[i, t]) == (u[i, t] - unit_init_status[i]))
            for t in range(1, T):
                self.m.addConstr((s[i, t] - d[i, t]) == (u[i, t] - u[i, t - 1]))

        # 偏离变量约束
        if use_guidance:
            for i in range(G):
                for t in range(T):
                    uh = int(u_hat[i, t])

                    self.m.addConstr(
                        z_dev[i, t] >= u[i, t] - uh,
                        name='soft_fix_pos' + '(' + str(i) + ',' + str(t) + ')'
                    )

                    self.m.addConstr(
                        z_dev[i, t] >= uh - u[i, t],
                        name='soft_fix_neg' + '(' + str(i) + ',' + str(t) + ')'
                    )

        # MIPStart策略
        if use_mip_start:

            # 允许 Gurobi 花一些节点尝试补全部分 MIPStart
            # self.m.Params.StartNodeLimit = 1000

            # 置信度阈值：只有 u_conf >= 0.95 的变量才设置 Start
            conf_start_thr = 0.95

            # 记录哪些 u[i,t] 被设置了 Start
            start_mask = np.zeros((G, T), dtype=bool)
            start_val = np.zeros((G, T), dtype=int)

            for i in range(G):

                U_i = max(0, min(T, int(unit_init_status[i] * (min_on[i] - T_init[i]))))
                L_i = max(0, min(T, int((1 - unit_init_status[i]) * (min_off[i] + T_init[i]))))
                fixed_len = U_i + L_i

                for t in range(T):

                    uh = int(u_hat[i, t])
                    conf = float(u_conf[i, t])

                    # VarHint：可以给所有 u[i,t]
                    # 如果该时段受初始状态约束强制固定，则提示值也用固定值
                    if t < fixed_len:
                        hint_val = int(unit_init_status[i])
                        hint_pri = 100
                    else:
                        hint_val = uh
                        hint_pri = int(100 * conf)

                    u[i, t].VarHintVal = hint_val
                    u[i, t].VarHintPri = max(1, min(100, hint_pri))

                    # MIPStart：只给高置信度位置
                    if t < fixed_len:
                        start_value = int(unit_init_status[i])
                        u[i, t].Start = start_value

                        start_mask[i, t] = True
                        start_val[i, t] = start_value

                    elif conf >= conf_start_thr:
                        # 只对高置信度预测设置 Start
                        start_value = uh
                        u[i, t].Start = start_value

                        start_mask[i, t] = True
                        start_val[i, t] = start_value

                    else:
                        # 低置信度变量不设置 Start，让 Gurobi 自己决定
                        u[i, t].Start = GRB.UNDEFINED

                        start_mask[i, t] = False

            # s,d 只在相邻 u 都有 Start 时设置
            for i in range(G):
                for t in range(T):

                    if not start_mask[i, t]:
                        s[i, t].Start = GRB.UNDEFINED
                        d[i, t].Start = GRB.UNDEFINED
                        continue

                    curr_u = int(start_val[i, t])

                    if t == 0:
                        prev_u = int(unit_init_status[i])
                        prev_defined = True
                    else:
                        prev_defined = start_mask[i, t - 1]
                        if prev_defined:
                            prev_u = int(start_val[i, t - 1])
                        else:
                            prev_u = None

                    if prev_defined:
                        s[i, t].Start = max(0, curr_u - prev_u)
                        d[i, t].Start = max(0, prev_u - curr_u)
                    else:
                        s[i, t].Start = GRB.UNDEFINED
                        d[i, t].Start = GRB.UNDEFINED


        self.u = u
        self.s = s
        self.d = d
        self.S = S
        self.P = P
        self.theta = theta
        self.P_ij = P_ij
        self.z_dev = z_dev

        self.G = G
        self.T = T
        self.u_hat = u_hat
        self.u_conf = u_conf

        self.original_cost_expr = original_cost
        self.soft_penalty_expr = soft_penalty
        self.total_cost_expr = total_cost
        # 更新模型
        self.m.update()
    def myOptimize(self):
        self.m.optimize()
        if self.m.status == GRB.INFEASIBLE:
            # print("模型不可行！开始计算IIS以进行诊断...")
            # self.m.computeIIS()
            # self.m.write("detailed_model.ilp")
            # print("详细IIS已写入 'detailed_model.ilp' 文件")
            # return None

            print("模型不可行！")
            return [None] * 17
        else:
            u_values = []
            s_values = []
            d_values = []
            # 记录整数变量取值
            for i in range(self.G):
                u_temp = []
                s_temp = []
                d_temp = []
                for t in range(self.T):
                    var1 = self.m.getVarByName(f'u({i},{t})')
                    var2 = self.m.getVarByName(f's({i},{t})')
                    var3 = self.m.getVarByName(f'd({i},{t})')
                    u_temp.append(var1.X)
                    s_temp.append(var2.X)
                    d_temp.append(var3.X)
                u_values.append(u_temp)
                s_values.append(s_temp)
                d_values.append(d_temp)
            u_values = np.array(u_values)
            s_values = np.array(s_values)
            d_values = np.array(d_values)
            u_values = (u_values > 0.5).astype(np.int8)
            s_values = (s_values > 0.5).astype(np.int8)
            d_values = (d_values > 0.5).astype(np.int8)

            # 原目标函数值
            original_obj = self.original_cost_expr.getValue()

            # 置信度搜索引导惩罚值
            penalty_obj = self.soft_penalty_expr.getValue()

            # 总目标函数值
            total_obj = self.m.ObjVal

            # 求解时间
            runtime = self.m.runtime

            # 模型大小指标
            orig_rows = self.m.NumConstrs
            orig_cols = self.m.NumVars
            orig_nonzeros = self.m.NumNZs

            node_count = self.m.NodeCount

            self.m.reset()
            t0 = time.perf_counter()
            presolved = self.m.presolve()
            t1 = time.perf_counter()
            presolve_time = t1 - t0

            pres_rows = presolved.NumConstrs
            pres_cols = presolved.NumVars
            pres_nonzeros = presolved.NumNZs

            # 统计变量类型
            type_count = defaultdict(int)
            for var in presolved.getVars():
                vtype = var.VType
                type_count[vtype] += 1

            # 释放预处理模型资源
            presolved.dispose()

            continuous_num, binary_num = type_count.get('C', 0), type_count.get('B', 0)

            return u_values, s_values, d_values, original_obj, penalty_obj, total_obj, runtime, continuous_num, binary_num, orig_rows, orig_cols, orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, node_count



