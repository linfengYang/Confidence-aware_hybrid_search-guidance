import torch
from utlis.read_dataset import read_dataset_from_txt
from utlis.create_dataset import UCLoadDataset
from torch.utils.data import DataLoader
from run.model.RGCTCN import *
from run.trainer import trainer
from utlis.pre_processing_trainning_data import pre_processing_data
from utlis.set_seed import set_seed

# 固定随机种子，默认42
set_seed(42, deterministic=False)  # deterministic参数可选，是否使用确定性算法

num_units = 162
num_nodes = 354
system_load_scaler_save_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\scaler\system_load_scaler_354.pkl"

# 读取数据
dataset_train_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_162_354\train"
dataset_val_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_162_354\val"

X_train, Y_train = read_dataset_from_txt(dataset_train_dir, num_units, num_nodes)
X_val, Y_val = read_dataset_from_txt(dataset_val_dir, num_units, num_nodes)

# 数据预处理
X_train_scaled, X_val_scaled = pre_processing_data(X_train, X_val, system_load_scaler_save_dir)

# 创建Dataset实例
train_dataset = UCLoadDataset(X_train_scaled, Y_train)
val_dataset = UCLoadDataset(X_val_scaled, Y_val)
# 创建DataLoader
batch_size = 64
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

model = RGCTCN_L(num_units=num_units, input_channels=num_nodes + 1)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

# 超参数
epochs = 1000
patience = 30
clip = 1.0
warmup = 50
lr = 1e-4
loss_fn = BCEW_TS_Loss(lambda_smooth=0.005)
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(epochs), eta_min=1e-6)

my_trainer = trainer(model, loss_fn, optimizer, scheduler, device, patience, epochs, clip, warmup)
my_trainer.train(train_loader, val_loader)