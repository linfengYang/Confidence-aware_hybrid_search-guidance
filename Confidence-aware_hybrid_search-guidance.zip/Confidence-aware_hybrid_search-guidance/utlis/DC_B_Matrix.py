import numpy as np

def Bmatrix(N, lines, lines_data):
    n_nodes = N

    B_matrix = np.zeros((n_nodes, n_nodes))

    for idx, (line, d) in enumerate(zip(lines, lines_data)):
        i, j = line - 1
        x = d[1]

        if np.isclose(x, 0, atol=1e-5):
            x = 1e-5
        b_ij = 1.0 / x

        B_matrix[i, j] -= b_ij
        B_matrix[j, i] -= b_ij

        B_matrix[i, i] += b_ij
        B_matrix[j, j] += b_ij
    return B_matrix