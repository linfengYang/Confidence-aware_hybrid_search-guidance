import numpy as np
import joblib

def compare_results(Origin_dir, Acceleration_dir, eta, solver_level_guidance):
    if solver_level_guidance == 1:
        print(f"===============[eta: {eta}]=======[With-solver-level-guidance]===============")
    else:
        print(f"===============[eta: {eta}]=======[Without-solver-level-guidance]===============")

    origin = joblib.load(Origin_dir)
    Acceleration = joblib.load(Acceleration_dir)

    origin_solution_obj = np.array(origin["original_obj"])
    Acceleration_solution_obj = np.array(Acceleration["original_obj"])

    origin_nodes = np.array(origin["explored_node"])
    Acceleration_nodes = np.array(Acceleration["explored_node"])

    origin_optimize_time = np.array(origin["optimize_time"])
    Acceleration_optimize_time = np.array(Acceleration["optimize_time"])
    model_infer_time = np.array(Acceleration["model_infer_time"])

    print("Average optimize time of OG-SCUC: ", np.mean(origin_optimize_time), "\t", "Average optimize time of LA-SCUC: ", np.mean(Acceleration_optimize_time + model_infer_time))
    print("Average acceleration ratio: ", np.sum(origin_optimize_time) / np.sum(Acceleration_optimize_time + model_infer_time))
    print("Average nodes of OG-SCUC: ", np.sum(origin_nodes) / origin_nodes.shape[0], "\t", "Average nodes of LA-SCUC: ", np.sum(Acceleration_nodes) / Acceleration_nodes.shape[0])
    print("Number of RE <= 0.01%: ", np.sum((np.abs(Acceleration_solution_obj - origin_solution_obj) / origin_solution_obj) <= 1e-4))
    print("Number of RE <= 0.05%: ", np.sum((np.abs(Acceleration_solution_obj - origin_solution_obj) / origin_solution_obj) <= 5 * 1e-4))
    print("Number of RE <= 0.1%: ", np.sum((np.abs(Acceleration_solution_obj - origin_solution_obj) / origin_solution_obj) <= 1e-3))

    print("\n")

if __name__ == "__main__":
    print("====================SCUC-354====================")
    # 354
    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Acceleration_Optimization_info_eta_[1.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\NoMIPStart_Acceleration_Optimization_info_eta_[1.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Acceleration_Optimization_info_eta_[10.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\NoMIPStart_Acceleration_Optimization_info_eta_[10.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Acceleration_Optimization_info_eta_[25.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\NoMIPStart_Acceleration_Optimization_info_eta_[25.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Acceleration_Optimization_info_eta_[50.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\NoMIPStart_Acceleration_Optimization_info_eta_[50.0]_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\Origin_Optimization_info_MILP_354.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_354\OnlyMIPStart_Acceleration_Optimization_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta="Only solver_level_guidance", solver_level_guidance=1)

    print("====================SCUC-236====================")
    print("\n")


    # 236
    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Acceleration_Optimization_info_eta_[1.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\NoMIPStart_Acceleration_Optimization_info_eta_[1.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Acceleration_Optimization_info_eta_[10.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\NoMIPStart_Acceleration_Optimization_info_eta_[10.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Acceleration_Optimization_info_eta_[25.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\NoMIPStart_Acceleration_Optimization_info_eta_[25.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Acceleration_Optimization_info_eta_[50.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\NoMIPStart_Acceleration_Optimization_info_eta_[50.0]_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\Origin_Optimization_info_MILP_236.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_236\OnlyMIPStart_Acceleration_Optimization_info_MILP_236.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta="Only solver_level_guidance", solver_level_guidance=1)

    print("====================IEEE-118====================")
    print("\n")

    # 118
    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Acceleration_Optimization_info_eta_[1.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\NoMIPStart_Acceleration_Optimization_info_eta_[1.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=1.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Acceleration_Optimization_info_eta_[10.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\NoMIPStart_Acceleration_Optimization_info_eta_[10.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=10.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Acceleration_Optimization_info_eta_[25.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\NoMIPStart_Acceleration_Optimization_info_eta_[25.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=25.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Acceleration_Optimization_info_eta_[50.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=1)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\NoMIPStart_Acceleration_Optimization_info_eta_[50.0]_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta=50.0, solver_level_guidance=0)

    Origin_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\Origin_Optimization_info_MILP_118.pkl"
    Acceleration_dir = r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\experiment_results\DC_SCUC_118\OnlyMIPStart_Acceleration_Optimization_info_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir, eta="Only solver_level_guidance", solver_level_guidance=1)