import numpy as np
import joblib

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from pathlib import Path


# ============================================================
# 1. 文件路径
# ============================================================
BASE_DIR = Path(
    r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework"
    r"\experiment_results"
)

SAVE_DIR = BASE_DIR / "figures"
SAVE_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. 读取求解时间
# ============================================================
def load_optimize_time(file_path):
    result = joblib.load(file_path)

    return np.asarray(
        result["optimize_time"],
        dtype=float
    ).reshape(-1)


origin_118_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_118"
    / "Origin_Optimization_info_MILP_118.pkl"
)

acceleration_118_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_118"
    / "Acceleration_Optimization_info_eta_[10.0]_MILP_118.pkl"
)


origin_236_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_236"
    / "Origin_Optimization_info_MILP_236.pkl"
)

acceleration_236_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_236"
    / "Acceleration_Optimization_info_eta_[10.0]_MILP_236.pkl"
)


origin_354_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_354"
    / "Origin_Optimization_info_MILP_354.pkl"
)

acceleration_354_optimize_time = load_optimize_time(
    BASE_DIR
    / "DC_SCUC_354"
    / "Acceleration_Optimization_info_eta_[10.0]_MILP_354.pkl"
)


# ============================================================
# 3. 清洗配对数据
# ============================================================
def clean_paired_data(
    origin_time,
    acceleration_time,
    system_name
):
    if len(origin_time) != len(acceleration_time):
        raise ValueError(
            f"{system_name} 数据长度不一致："
            f"{len(origin_time)} 和 "
            f"{len(acceleration_time)}。"
        )

    valid_mask = (
        np.isfinite(origin_time)
        & np.isfinite(acceleration_time)
        & (origin_time > 0)
        & (acceleration_time > 0)
    )

    removed_number = (
        len(origin_time)
        - np.sum(valid_mask)
    )

    if removed_number > 0:
        print(
            f"{system_name}: 删除了 "
            f"{removed_number} 个无效样本。"
        )

    return (
        origin_time[valid_mask],
        acceleration_time[valid_mask]
    )


origin_118_optimize_time, acceleration_118_optimize_time = (
    clean_paired_data(
        origin_118_optimize_time,
        acceleration_118_optimize_time,
        "IEEE 118-bus"
    )
)

origin_236_optimize_time, acceleration_236_optimize_time = (
    clean_paired_data(
        origin_236_optimize_time,
        acceleration_236_optimize_time,
        "SCUC-236"
    )
)

origin_354_optimize_time, acceleration_354_optimize_time = (
    clean_paired_data(
        origin_354_optimize_time,
        acceleration_354_optimize_time,
        "SCUC-354"
    )
)


# ============================================================
# 4. Seaborn 论文风格
# ============================================================
sns.set_theme(
    context="paper",
    style="whitegrid",
    font="Times New Roman",
    font_scale=1.0,
    rc={
        "axes.linewidth": 0.8,
        "axes.edgecolor": "#333333",
        "axes.labelcolor": "#222222",
        "xtick.color": "#333333",
        "ytick.color": "#333333",
        "grid.color": "#D9D9D9",
        "grid.linewidth": 0.55,
        "grid.alpha": 0.75,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "mathtext.fontset": "stix"
    }
)

plt.rcParams.update(
    {
        "font.family": "Times New Roman",
        "font.size": 8.5,
        "axes.labelsize": 9,
        "axes.titlesize": 9.5,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "savefig.dpi": 600
    }
)


# 论文配色
SCATTER_COLORS = [
    "#4C78A8",
    "#59A14F",
    "#E07B39"
]

REFERENCE_COLOR = "#C44E52"

BOX_COLORS = [
    "#A8C4E0",
    "#A9D3B2",
    "#EBC39B"
]


# ============================================================
# 5. 整理散点图数据
# ============================================================
scatter_data = [
    (
        "IEEE 118-bus",
        origin_118_optimize_time,
        acceleration_118_optimize_time
    ),
    (
        "SCUC-236",
        origin_236_optimize_time,
        acceleration_236_optimize_time
    ),
    (
        "SCUC-354",
        origin_354_optimize_time,
        acceleration_354_optimize_time
    )
]

panel_labels = ["(a)", "(b)", "(c)"]


# ============================================================
# 6. 求解时间散点图
# ============================================================
fig, axes = plt.subplots(
    1,
    3,
    figsize=(7.5, 2.85)
)

for index, (
    ax,
    panel_label,
    system_data
) in enumerate(
    zip(
        axes,
        panel_labels,
        scatter_data
    )
):
    system_name, origin_time, acceleration_time = system_data

    plot_df = pd.DataFrame(
        {
            "OG-SCUC": origin_time,
            "LA-SCUC": acceleration_time
        }
    )

    sns.scatterplot(
        data=plot_df,
        x="OG-SCUC",
        y="LA-SCUC",
        ax=ax,
        color=SCATTER_COLORS[index],
        s=24,
        alpha=0.65,
        edgecolor="white",
        linewidth=0.35,
        legend=False,
        zorder=3
    )

    minimum_value = min(
        origin_time.min(),
        acceleration_time.min()
    )

    maximum_value = max(
        origin_time.max(),
        acceleration_time.max()
    )

    data_range = maximum_value - minimum_value

    lower_limit = max(
        0,
        minimum_value - 0.08 * data_range
    )

    upper_limit = (
        maximum_value
        + 0.06 * data_range
    )

    ax.plot(
        [lower_limit, upper_limit],
        [lower_limit, upper_limit],
        linestyle=(0, (5, 3)),
        linewidth=1.3,
        color=REFERENCE_COLOR,
        zorder=2
    )

    ax.set_xlim(
        lower_limit,
        upper_limit
    )

    ax.set_ylim(
        lower_limit,
        upper_limit
    )

    ax.set_aspect(
        "equal",
        adjustable="box"
    )

    ax.set_title(
        f"{panel_label} {system_name}",
        fontweight="bold",
        pad=7
    )

    # 取消每个子图单独的坐标轴标题
    ax.set_xlabel("")
    ax.set_ylabel("")

    ax.xaxis.set_major_locator(
        MaxNLocator(nbins=5)
    )

    ax.yaxis.set_major_locator(
        MaxNLocator(nbins=5)
    )

    faster_number = int(
        np.sum(
            acceleration_time
            < origin_time
        )
    )

    total_number = len(origin_time)

    faster_percentage = (
        faster_number
        / total_number
        * 100
    )

    ax.text(
        0.05,
        0.95,
        (
            f"Faster instances\n"
            f"{faster_number}/{total_number} "
            f"({faster_percentage:.1f}%)"
        ),
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=7.4,
        color="#333333",
        bbox={
            "boxstyle": "round,pad=0.28",
            "facecolor": "white",
            "edgecolor": "#B8B8B8",
            "linewidth": 0.55,
            "alpha": 0.90
        }
    )


# 使用 fig.text 手动控制公共坐标轴标题的位置
fig.text(
    0.5,
    0.045,
    r"OG-SCUC solution time, $T_{\mathrm{OG}}$ (s)",
    ha="center",
    va="center",
    fontsize=9.2
)

fig.text(
    0.025,
    0.49,
    r"LA-SCUC solution time, $T_{\mathrm{LA}}$ (s)",
    ha="center",
    va="center",
    rotation="vertical",
    fontsize=9.2
)


reference_handle = Line2D(
    [0],
    [0],
    color=REFERENCE_COLOR,
    linestyle=(0, (5, 3)),
    linewidth=1.3,
    label=r"$T_{\mathrm{LA}}=T_{\mathrm{OG}}$"
)

fig.legend(
    handles=[reference_handle],
    loc="upper center",
    bbox_to_anchor=(0.5, 0.985),
    frameon=False,
    ncol=1
)


# 手动增加四周边距
fig.subplots_adjust(
    left=0.085,
    right=0.985,
    bottom=0.20,
    top=0.82,
    wspace=0.22
)


scatter_pdf_path = (
    SAVE_DIR
    / "solution_time_scatter.pdf"
)

scatter_png_path = (
    SAVE_DIR
    / "solution_time_scatter.png"
)

fig.savefig(
    scatter_pdf_path,
    bbox_inches="tight",
    pad_inches=0.10
)

fig.savefig(
    scatter_png_path,
    dpi=600,
    bbox_inches="tight",
    pad_inches=0.10
)

plt.close(fig)



# ============================================================
# 7. 加速比数据
# ============================================================
speedup_118 = (
    origin_118_optimize_time
    / acceleration_118_optimize_time
)

speedup_236 = (
    origin_236_optimize_time
    / acceleration_236_optimize_time
)

speedup_354 = (
    origin_354_optimize_time
    / acceleration_354_optimize_time
)


speedup_df = pd.DataFrame(
    {
        "Test system": (
            ["IEEE 118-bus"] * len(speedup_118)
            + ["SCUC-236"] * len(speedup_236)
            + ["SCUC-354"] * len(speedup_354)
        ),
        "Speedup ratio": np.concatenate(
            [
                speedup_118,
                speedup_236,
                speedup_354
            ]
        )
    }
)


system_order = [
    "IEEE 118-bus",
    "SCUC-236",
    "SCUC-354"
]


# ============================================================
# 8. 加速比箱线图
# ============================================================
fig, ax = plt.subplots(
    figsize=(4.4, 3.05)
)

# 箱线图
sns.boxplot(
    data=speedup_df,
    x="Test system",
    y="Speedup ratio",
    order=system_order,
    palette=BOX_COLORS,
    width=0.48,
    linewidth=0.95,
    saturation=0.80,

    # 关闭箱线图自带的离群点，避免与散点重复
    showfliers=False,

    medianprops={
        "color": "#A43B36",
        "linewidth": 1.7
    },

    whiskerprops={
        "color": "#444444",
        "linewidth": 0.95
    },

    capprops={
        "color": "#444444",
        "linewidth": 0.95
    },

    boxprops={
        "edgecolor": "#444444",
        "linewidth": 0.95
    },

    ax=ax,
    zorder=2
)


# 为不同测试系统设置彩色算例点
point_palette = {
    "IEEE 118-bus": "#4C78A8",
    "SCUC-236": "#59A14F",
    "SCUC-354": "#E6863B"
}

sns.stripplot(
    data=speedup_df,
    x="Test system",
    y="Speedup ratio",
    order=system_order,

    # 根据测试系统分别设置颜色
    hue="Test system",
    palette=point_palette,

    size=2.8,
    alpha=0.32,
    jitter=0.18,
    dodge=False,

    edgecolor="white",
    linewidth=0.20,

    ax=ax,
    zorder=1
)


# stripplot 会自动创建图例，这里删除
legend = ax.get_legend()
if legend is not None:
    legend.remove()


# 无加速参考线
ax.axhline(
    y=1.0,
    linestyle=(0, (5, 3)),
    linewidth=1.2,
    color=REFERENCE_COLOR,
    zorder=3
)

ax.text(
    2.43,
    1.04,
    "No speedup",
    color=REFERENCE_COLOR,
    fontsize=7.6,
    ha="right",
    va="bottom"
)


ax.set_xlabel("")

ax.set_ylabel(
    r"Instance-wise speedup, "
    r"$T_{\mathrm{OG}}/T_{\mathrm{LA}}$"
)

ax.yaxis.set_major_locator(
    MaxNLocator(nbins=6)
)

ax.grid(
    axis="x",
    visible=False
)

ax.set_axisbelow(True)


maximum_speedup = speedup_df[
    "Speedup ratio"
].max()

minimum_speedup = speedup_df[
    "Speedup ratio"
].min()

ax.set_ylim(
    max(
        0,
        minimum_speedup * 0.88
    ),
    maximum_speedup * 1.06
)


fig.subplots_adjust(
    left=0.17,
    right=0.975,
    bottom=0.18,
    top=0.97
)


boxplot_pdf_path = (
    SAVE_DIR
    / "speedup_boxplot.pdf"
)

boxplot_png_path = (
    SAVE_DIR
    / "speedup_boxplot.png"
)

fig.savefig(
    boxplot_pdf_path,
    bbox_inches="tight",
    pad_inches=0.10
)

fig.savefig(
    boxplot_png_path,
    dpi=600,
    bbox_inches="tight",
    pad_inches=0.10
)

plt.close(fig)



# ============================================================
# 9. 输出统计结果
# ============================================================
def print_summary(
    system_name,
    origin_time,
    acceleration_time
):
    speedup = (
        origin_time
        / acceleration_time
    )

    q1, median, q3 = np.percentile(
        speedup,
        [25, 50, 75]
    )

    faster_number = int(
        np.sum(
            acceleration_time
            < origin_time
        )
    )

    print("=" * 65)
    print(system_name)

    print(
        f"Average OG-SCUC time: "
        f"{np.mean(origin_time):.4f} s"
    )

    print(
        f"Average LA-SCUC time: "
        f"{np.mean(acceleration_time):.4f} s"
    )

    print(
        f"Speedup based on average times: "
        f"{np.mean(origin_time) / np.mean(acceleration_time):.4f}"
    )

    print(
        f"Median instance-wise speedup: "
        f"{median:.4f}"
    )

    print(
        f"Interquartile range: "
        f"[{q1:.4f}, {q3:.4f}]"
    )

    print(
        f"Faster instances: "
        f"{faster_number}/{len(speedup)} "
        f"({100 * faster_number / len(speedup):.2f}%)"
    )


print_summary(
    "IEEE 118-bus",
    origin_118_optimize_time,
    acceleration_118_optimize_time
)

print_summary(
    "SCUC-236",
    origin_236_optimize_time,
    acceleration_236_optimize_time
)

print_summary(
    "SCUC-354",
    origin_354_optimize_time,
    acceleration_354_optimize_time
)


print("=" * 65)
print("Figures saved to:")
print(scatter_pdf_path)
print(scatter_png_path)
print(boxplot_pdf_path)
print(boxplot_png_path)