from solver.DC_SCUC_Gurobi_model import DC_SCUC_Gurobi_model
import numpy as np
from time import time
import os

# 对负荷进行扰动生成不同的解
def load_perturbation(data, datasize):
    X = []
    nodes_load_P_all = []
    Y = []
    system_perturb_ratio = 0.1
    nodal_perturb_ratio = 0.05
    MIPGap = 0.0001
    MILP_flag = 1
    for i in np.random.choice(np.arange(0.96, 1.06, 0.01), size=10, replace=False):
        j = 1
        while j <= (datasize // 10):
            random_factor1 = np.random.uniform(low=1 - system_perturb_ratio, high=1 + system_perturb_ratio, size=24)
            P_D = data["P_D"] * i * random_factor1

            random_factor2 = np.random.uniform(low=1 - nodal_perturb_ratio, high=1 + nodal_perturb_ratio, size=(N, T))
            nodes_load_perturbed_P = data["nodes_load_P"][:, None] * random_factor2
            hourly_sum = nodes_load_perturbed_P.sum(axis=0, keepdims=True)
            nodes_load_percentage_P = nodes_load_perturbed_P / hourly_sum

            DC_SCUC = DC_SCUC_Gurobi_model(G, N, T, L, data["alpha"], data["beta"], data["gamma"],
                                           data["hot_su_cost"], data["cold_su_cost"],
                                           data["min_on"], data["min_off"], data["cold_su_t"], data["P_max"],
                                           data["P_min"], data["ramp_up"], data["ramp_down"], data["su_ramp"],
                                           data["sd_ramp"],
                                           data["unit_init_status"], data["T_init"], data["node_connections"],
                                           nodes_load_percentage_P, data["lines"], data["P_ij_max"],
                                           data["B_matrix"],
                                           P_D * 0.01, data["P_init"], data["unit_bus"], data["balance_node"], MIPGap,
                                           MILP_flag, u_hat=None, u_conf=None, eta_soft=0.25, use_guidance=False, use_mip_start=False)
            u_values, s_values, d_values, total_obj, runtime, continuous, binary, orig_rows, orig_cols, orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, node_count = DC_SCUC.myOptimize()
            if u_values is not None:
                X.append(P_D)
                nodes_load_P_all.append(nodes_load_perturbed_P)
                Y.append(u_values)
                j += 1
    X = np.array(X)
    nodes_load_P_all = np.array(nodes_load_P_all)
    Y = np.array(Y)
    return X, nodes_load_P_all, Y

def save_dataset_to_txt(X, nodes_load_percentage_P_all, Y, output_dir):
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    # 每个样本对应一个txt
    for i in range(X.shape[0]):
        file_name = os.path.join(output_dir, f"sample_{i:04d}.txt")
        with open(file_name, "w") as f:
            # 写入负荷序列（第一行）
            f.write(" ".join([f"{x:.2f}" for x in X[i]]) + "\n")
            # 写入节点负荷占比（每个节点一行）
            for j in range(nodes_load_percentage_P_all.shape[1]):
                f.write(" ".join([f"{nodes_load_percentage_P_all[i, j, t]:.6f}" for t in range(nodes_load_percentage_P_all.shape[2])]) + "\n")
            # 写入每个机组的决策（每个机组一行）
            for unit in range(Y.shape[1]):
                f.write(" ".join([str(int(Y[i, unit, t])) for t in range(Y.shape[2])]) + "\n")
    print("数据集生成完成！")

if __name__ == "__main__":

    # 固定随机数种子
    np.random.seed(2026)

    # 参数获取
    G = int(162)
    N = int(354)
    T = int(24)
    L = int(561)
    # 获取机组参数
    from utlis.get_162_354_data import get_data
    data = get_data(r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\utlis\SCUC354.txt")
    # 数据集大小
    train_size = 4000
    val_size = 400
    test_size = 400

    # 模型生成
    start = time()
    X_train, nodes_load_percentage_P_all_train, Y_train = load_perturbation(data, train_size)
    X_val, nodes_load_percentage_P_all_val, Y_val = load_perturbation(data, val_size)
    X_test, nodes_load_percentage_P_all_test, Y_test = load_perturbation(data, test_size)

    save_dataset_to_txt(X_train, nodes_load_percentage_P_all_train, Y_train, r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_162_354\train")
    save_dataset_to_txt(X_val, nodes_load_percentage_P_all_val, Y_val, r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_162_354\val")
    save_dataset_to_txt(X_test, nodes_load_percentage_P_all_test, Y_test, r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\dataset\DC_SCUC_162_354\test")

    end = time()
    print("数据生成时间：", end - start)