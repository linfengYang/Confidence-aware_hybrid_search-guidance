import numpy as np
import os
from utlis.DC_B_Matrix import Bmatrix

def lines_to_node_connections(lines):
    if lines.ndim != 2 or lines.shape[1] != 2:
        raise ValueError("lines must be a 2D array with shape (E, 2)")

    n = int(lines.max())
    adj = [[i] for i in range(n)]

    for a, b in lines:
        u, v = a - 1, b - 1
        adj[u].append(v)
        adj[v].append(u)

    return {i: adj[i] for i in range(n)}

def get_data(file_path):
    T = 24
    alpha = []
    beta = []
    gamma = []
    hot_su_cost = []
    min_on = []
    min_off = []
    P_max = []
    P_min = []
    ramp_up = []
    ramp_down = []
    T_init = []
    lines = []
    lines_data = []
    P_ij_max = []
    nodes_load_P = [0] * 354
    unit_bus = []
    P_D = []

    with open(file_path, "r") as f:
        data = f.readline()
        info = [int(x) if '.' not in x else float(x) for x in data.split()]
        # 读取基础信息
        G, N, L, balance_node, standard_P = info[-1], info[0], info[1], info[2], info[3]
        # 读取机组数据
        for i in range(G):
            data = f.readline()
            info = [int(x) if '.' not in x else float(x) for x in data.split()]
            unit_bus.append(info[1] - 1)
            alpha.append(info[2])
            beta.append(info[3])
            gamma.append(info[4])
            P_max.append(info[5])
            P_min.append(info[6])
            min_off.append(info[9])
            min_on.append(info[10])
            T_init.append(info[11])
            ramp_up.append(info[12])
            ramp_down.append(info[12])
            hot_su_cost.append(info[13])

        # 读取线路信息
        data = f.readline()
        data = f.readline()
        info = [int(x) if '.' not in x else float(x) for x in data.split()]
        while info[0] != 0:
            lines.append([info[1], info[2]])
            lines_data.append([info[4], info[5]])
            P_ij_max.append(info[7])
            data = f.readline()
            info = [int(x) if '.' not in x else float(x) for x in data.split()]

        # data = f.readline()
        # info = [int(x) if '.' not in x else float(x) for x in data.split()]
        # while info[0] != 0:
        #     lines.append([info[1], info[2]])
        #     lines_data.append([info[4], info[5]])
        #     P_ij_max.append(info[7])
        #     data = f.readline()
        #     info = [int(x) if '.' not in x else float(x) for x in data.split()]

        for i in range(T):
            data = f.readline()
            info = [int(x) if '.' not in x else float(x) for x in data.split()]
            P_D.append(info[1])

        data = f.readline()
        data = f.readline()
        info = [int(x) if '.' not in x else float(x) for x in data.split()]
        while info[0] != 0:
            nodes_load_P[info[0] - 1] = info[1]
            data = f.readline()
            info = [int(x) if '.' not in x else float(x) for x in data.split()]

    alpha = np.array(alpha, dtype=np.float32)
    beta = np.array(beta, dtype=np.float32)
    gamma = np.array(gamma, dtype=np.float32)
    hot_su_cost = np.array(hot_su_cost)
    cold_su_cost = hot_su_cost.copy() * 2
    min_on = np.array(min_on)
    min_off = np.array(min_off)
    cold_su_t = np.array([4, 1, 1, 4, 1, 1, 3, 1, 1, 3, 1, 4, 1, 3, 1, 1, 4, 3,
                          3, 3, 3, 3, 2, 1, 2, 3, 1, 1, 1, 1, 3, 2, 4, 2, 4, 4,
                          3, 3, 3, 4, 1, 4, 3, 1, 2, 4, 2, 4, 2, 2, 4, 3, 1, 3,
                          4, 1, 1, 4, 1, 1, 3, 1, 1, 3, 1, 4, 1, 3, 1, 1, 4, 3,
                          3, 3, 3, 3, 2, 1, 2, 3, 1, 1, 1, 1, 3, 2, 4, 2, 4, 4,
                          3, 3, 3, 4, 1, 4, 3, 1, 2, 4, 2, 4, 2, 2, 4, 3, 1, 3,
                          4, 1, 1, 4, 1, 1, 3, 1, 1, 3, 1, 4, 1, 3, 1, 1, 4, 3,
                          3, 3, 3, 3, 2, 1, 2, 3, 1, 1, 1, 1, 3, 2, 4, 2, 4, 4,
                          3, 3, 3, 4, 1, 4, 3, 1, 2, 4, 2, 4, 2, 2, 4, 3, 1, 3])
    P_max = np.array(P_max, dtype=np.float32) / standard_P
    P_min = np.array(P_min, dtype=np.float32) / standard_P
    ramp_up = np.array(ramp_up, dtype=np.float32) / standard_P
    ramp_down = np.array(ramp_down, dtype=np.float32) / standard_P
    su_ramp = P_min.copy()
    sd_ramp = su_ramp.copy()
    T_init = np.array(T_init)
    P_init = (P_max.copy()) * 0.5
    unit_init_status = np.ones(G, dtype=np.int8)
    lines = np.array(lines)
    node_connections = lines_to_node_connections(lines)
    lines_data = np.array(lines_data, dtype=np.float32)
    B_matrix = Bmatrix(N, lines, lines_data)
    P_ij_max = np.array(P_ij_max, dtype=np.float32) / standard_P
    nodes_load_P = np.array(nodes_load_P, dtype=np.float32)
    unit_bus = np.array(unit_bus)
    P_D = np.array(P_D, dtype=np.float32)

    data = {"alpha":alpha, "beta":beta, "gamma":gamma, "hot_su_cost":hot_su_cost, "cold_su_cost":cold_su_cost,
            "min_on":min_on, "min_off":min_off, "cold_su_t":cold_su_t, "P_max":P_max, "P_min":P_min,
            "ramp_up":ramp_up, "ramp_down":ramp_down, "su_ramp":su_ramp, "sd_ramp":sd_ramp,
            "unit_init_status":unit_init_status, "T_init":T_init,
            "node_connections":node_connections, "nodes_load_P":nodes_load_P,
            "lines":lines, "P_ij_max":P_ij_max, "B_matrix":B_matrix,
            "P_init":P_init, "unit_bus":unit_bus, "P_D":P_D, "balance_node":balance_node}

    return data


if __name__ == '__main__':
    data = get_data(r"C:\Users\kentis\PycharmProjects\NN_Acceleration_Framework\utlis\SCUC354.txt")
    print(data["P_D"])
