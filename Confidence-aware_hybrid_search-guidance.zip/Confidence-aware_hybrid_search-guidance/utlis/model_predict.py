import numpy as np
import torch

def predict_u_by_model(P_D_raw, nodes_load_percentage_P, model, scaler, device, threshold=0.5):
    # 转换输入格式
    P_D_raw = np.asarray(P_D_raw, dtype=np.float32)
    nodes_load_percentage_P = np.asarray(nodes_load_percentage_P, dtype=np.float32)
    N, T = nodes_load_percentage_P.shape

    # 归一化总负荷
    P_D_scaled = scaler.transform(P_D_raw.reshape(-1, 1)).reshape(1, T)  # [1, T]

    node_feature = nodes_load_percentage_P.copy()

    # 拼接数据
    x_feat = np.concatenate([P_D_scaled, node_feature], axis=0).astype(np.float32)  # [N + 1, T]

    # 转换为Tensor
    x_tensor = torch.from_numpy(x_feat).float().unsqueeze(0).to(device)

    # 模型预测
    model.eval()
    with torch.no_grad():
        logits = model(x_tensor)  # [1, G, T]
        prob = torch.sigmoid(logits)  # [1, G, T]

    prob = prob.squeeze(0).cpu().numpy()  # [G, T]

    # 二值化与置信度
    u_hat = (prob >= threshold).astype(int)
    u_conf = 2.0 * np.abs(prob - 0.5)

    return u_hat, u_conf, prob