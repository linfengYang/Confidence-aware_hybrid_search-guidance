import os
import numpy as np

def read_dataset_from_txt(dir, num_units, num_nodes):
    # 获取所有样本文件
    sample_files = sorted([f for f in os.listdir(dir) if f.endswith('.txt')])

    if not sample_files:
        raise ValueError(f"目录 {dir} 中没有找到样本文件")

    # 从第一个样本确定序列长度
    first_file = os.path.join(dir, sample_files[0])
    with open(first_file, 'r') as f:
        lines = f.readlines()

    sequence_length = len(lines[0].split())

    # 初始化数组
    num_samples = len(sample_files)
    # 节点数 + 1（总负荷信息）
    X = np.zeros((num_samples, num_nodes + 1, sequence_length))
    Y = np.zeros((num_samples, num_units, sequence_length))

    # 加载每个样本
    for i, filename in enumerate(sample_files):
        filepath = os.path.join(dir, filename)
        with open(filepath, 'r') as f:
            lines = f.readlines()

        # 读取负荷序列和负荷占比序列
        for k in range(num_nodes + 1):
            X[i, k] = [float(x) for x in lines[k].split()]

        # 读取机组决策序列（后续行）
        for j in range(num_nodes + 1, len(lines)):
            Y[i, j - num_nodes - 1] = [int(x) for x in lines[j].split()]

    return X, Y