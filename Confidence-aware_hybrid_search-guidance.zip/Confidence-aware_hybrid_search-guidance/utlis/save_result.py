import joblib
import os

def save_results(u_values, original_obj, penalty_obj, total_obj, optimize_time, model_infer_time, continuous_var_num, binary_var_num, orig_rows, orig_cols,
                 orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, explored_node, name, output_dir):

    # create the results dictionary
    results = {
        "u_values": u_values,
        "original_obj": original_obj,
        "penalty_obj": penalty_obj,
        "total_obj": total_obj,
        "optimize_time": optimize_time,
        "model_infer_time": model_infer_time,
        "continuous_var_num": continuous_var_num,
        "binary_var_num": binary_var_num,
        "orig_rows": orig_rows,
        "orig_cols": orig_cols,
        "orig_nonzeros": orig_nonzeros,
        "pres_rows": pres_rows,
        "pres_cols": pres_cols,
        "pres_nonzeros": pres_nonzeros,
        "presolve_time": presolve_time,
        "explored_node": explored_node

    }

    # generate filename
    filename = f"{name}.pkl"
    filepath = os.path.join(output_dir, filename)

    # save results
    joblib.dump(results, filepath)
    print(f"save results to: {filepath}")

    return filepath